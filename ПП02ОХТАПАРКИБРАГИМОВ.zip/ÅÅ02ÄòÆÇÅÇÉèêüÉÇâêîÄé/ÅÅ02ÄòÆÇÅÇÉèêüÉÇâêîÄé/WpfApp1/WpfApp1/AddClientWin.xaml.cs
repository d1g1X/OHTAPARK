﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfApp1.Entities;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для AddClientWin.xaml
    /// </summary>
    public partial class AddClientWin : Window
    {
        IbragimovOhtaParkEntities db = new IbragimovOhtaParkEntities();
        NewOrderWin orderWin;
        public AddClientWin(NewOrderWin newOrderWin)
        {
            InitializeComponent();
            orderWin = newOrderWin;
        }

        private void BackB_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        public bool IsValidEmail(string email)
        {
            string pattern = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";
            return Regex.IsMatch(email, pattern);
        }

        private void PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = !e.Text.All(char.IsDigit);
        }

        private void AddB_Click(object sender, RoutedEventArgs e)
        {
            if (SecondNameTb.Text != string.Empty && FirstNameTb.Text != string.Empty &&
            PatronymicTb.Text != string.Empty && PasportSeriaTb.Text != string.Empty &&
            PasportNumberTb.Text != string.Empty && BirthDateDp.SelectedDate != null &&
            MailIndexTb.Text != string.Empty && CityNameTb.Text != string.Empty &&
            StreetNameTb.Text != string.Empty && HomeNumberTb.Text != string.Empty &&
            ApartamentNumberTb.Text != string.Empty && EmailTb.Text != string.Empty &&
            PasswordTb.Password != string.Empty)
            {
                if (!IsValidEmail(EmailTb.Text))
                {
                    MessageBox.Show("Неправильно указана почта");
                    return;
                }
                try
                {
                    var result = db.Clients.OrderByDescending(p => p.ClientCode).FirstOrDefault();

                    var client = new Clients
                    {
                        Surname = SecondNameTb.Text,
                        Name = FirstNameTb.Text,
                        Patronymic = PatronymicTb.Text,
                        PassportSeries = Convert.ToInt32(PasportSeriaTb.Text),
                        PassportNumber = Convert.ToInt32(PasportNumberTb.Text),
                        BirthDate = BirthDateDp.SelectedDate,
                        MailIndex = Convert.ToInt32(MailIndexTb.Text),
                        City = CityNameTb.Text,
                        Street = StreetNameTb.Text,
                        HouseNumber = HomeNumberTb.Text,
                        ApartamentNumber = Convert.ToInt32(ApartamentNumberTb.Text),
                        Email = EmailTb.Text,
                        Password = PasswordTb.Password,
                        ClientCode = result.ClientCode + 1,
                    };

                    db.Clients.Add(client);
                    db.SaveChanges();
                    MessageBox.Show("Успешно добавлено");
                    this.Close();
                    orderWin.GetClients();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
                MessageBox.Show("Не все поля заполнены");
        }
    }
}
