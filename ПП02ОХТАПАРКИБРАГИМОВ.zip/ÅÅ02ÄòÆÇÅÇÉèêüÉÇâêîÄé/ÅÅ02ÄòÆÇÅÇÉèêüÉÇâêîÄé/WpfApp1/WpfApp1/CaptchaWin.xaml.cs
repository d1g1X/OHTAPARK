﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для CaptchaWin.xaml
    /// </summary>
    public partial class CaptchaWin : Window
    {
        private string captchaCode;

        public CaptchaWin()
        {
            InitializeComponent();
            GenerateCaptcha();
        }

        private void GenerateCaptchaButton_Click(object sender, RoutedEventArgs e)
        {
            GenerateCaptcha();
        }

        private void GenerateCaptcha()
        {
            CaptchaCanvas.Children.Clear();
            Random random = new Random();
            captchaCode = random.Next(1000, 9999).ToString();

            double canvasWidth = CaptchaCanvas.Width;
            double canvasHeight = CaptchaCanvas.Height;

            double centerX = canvasWidth / 2;
            double centerY = canvasHeight / 2;

            double totalWidth = captchaCode.Length * 40; 
            double totalHeight = 30; 

            double startX = centerX - totalWidth / 2;
            double startY = centerY - totalHeight / 2;

            for (int i = 0; i < captchaCode.Length; i++)
            {
                TextBlock textBlock = CreateCaptchaCharacter(captchaCode[i].ToString(), random, startX + i * 40, startY);
                CaptchaCanvas.Children.Add(textBlock);
            }

            // Добавление шума (линии и точки)
            for (int i = 0; i < 8; i++)
            {
                Line line = CreateRandomLine(random, centerX, centerY);
                CaptchaCanvas.Children.Add(line);
            }

            for (int i = 0; i < 20; i++)
            {
                Ellipse ellipse = CreateRandomDot(random, centerX, centerY);
                CaptchaCanvas.Children.Add(ellipse);
            }

        }

        private TextBlock CreateCaptchaCharacter(string character, Random random, double xOffset, double yOffset)
        {
            double angle = random.Next(-10, 10);  

            // Уменьшаем диапазоны смещения по X и Y
            double xShift = random.Next(-5, 5);  
            double yShift = random.Next(-5, 5);  

            return new TextBlock
            {
                Text = character,
                FontSize = random.Next(25, 35),  // Случайный размер шрифта
                FontWeight = FontWeights.Bold,
                Foreground = new SolidColorBrush(RandomColor()),
                RenderTransform = new TransformGroup
                {
                    Children =
                    {
                        new TranslateTransform(xOffset + xShift, yOffset + yShift),
                        new RotateTransform(angle)
                    }
                }
            };
        }

        private Line CreateRandomLine(Random random, double centerX, double centerY)
        {
            return new Line
            {
                X1 = random.Next(0, (int)centerX),
                Y1 = random.Next(0, (int)centerY),
                X2 = random.Next((int)centerX, (int)CaptchaCanvas.Width),
                Y2 = random.Next((int)centerY, (int)CaptchaCanvas.Height),
                Stroke = new SolidColorBrush(RandomColor()),
                StrokeThickness = random.Next(1, 3)
            };
        }

        private Ellipse CreateRandomDot(Random random, double centerX, double centerY)
        {
            return new Ellipse
            {
                Width = random.Next(3, 6),
                Height = random.Next(3, 6),
                Fill = new SolidColorBrush(RandomColor()),
                Margin = new Thickness(random.Next(0, (int)CaptchaCanvas.Width), random.Next(0, (int)CaptchaCanvas.Height), 0, 0)
            };
        }

        private Color RandomColor()
        {
            Random random = new Random();
            return Color.FromArgb(255, (byte)random.Next(0, 256), (byte)random.Next(0, 256), (byte)random.Next(0, 256));
        }

        private void VerifyCaptchaButton_Click(object sender, RoutedEventArgs e)
        {
            string userInput = CaptchaTb.Text;

            if (userInput == captchaCode)
            {
                MessageBox.Show("Капча пройдена!");
                this.Close();
            }
            else
            {
                MessageBox.Show("Капча не пройдена! Попробуйте еще раз.");
                GenerateCaptcha();
            }
        }
    }
}
