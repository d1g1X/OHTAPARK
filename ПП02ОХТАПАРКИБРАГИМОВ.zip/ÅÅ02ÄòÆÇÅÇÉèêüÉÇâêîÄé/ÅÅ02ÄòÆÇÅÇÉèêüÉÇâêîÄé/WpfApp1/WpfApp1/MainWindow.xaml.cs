﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Migrations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApp1.Entities;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        IbragimovOhtaParkEntities db = new IbragimovOhtaParkEntities();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void AuthBtn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Получение сотрудника из базы данных на основе введённых логина и пароля
                var employee = db.Employees
                    .Where(emp => emp.Login == LoginTb.Text && emp.Password == PasswordPb.Password)
                    .FirstOrDefault();

                if (employee != null) 
                {
                    // Обновление времени последнего входа
                    employee.LastEntry = DateTime.Now;
                    db.Employees.AddOrUpdate(employee);
                    db.SaveChanges();

                    // Открытие соответствующего окна на основе роли сотрудника
                    switch (employee.Role_id)
                    {
                        case 1: // Администратор
                            LoginHistoryWin lhw = new LoginHistoryWin();
                            lhw.Show();
                            this.Close();
                            break;

                        case 2: // Менеджер
                        case 3: // Сотрудник
                            NewOrderWin now = new NewOrderWin();
                            now.Show();
                            this.Close();
                            break;

                        default:
                            break;
                    }
                }
                else if (string.IsNullOrWhiteSpace(LoginTb.Text) || string.IsNullOrWhiteSpace(PasswordPb.Password))
                {
                    MessageBox.Show("Укажите логин и пароль!");
                }
                else
                {
                    MessageBox.Show("Неверно введён логин или пароль!");
                    LoginTb.Text = ""; 
                    PasswordPb.Password = ""; 
                    new CaptchaWin().ShowDialog(); 
                }
            }
            catch (Exception ex)
            {
                // Обработка ошибок выполнения программы
                MessageBox.Show(ex.Message);
            }

        }

    }
}
