﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfApp1.Entities;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для AddOrderWin.xaml
    /// </summary>
    public partial class AddOrderWin : Window
    {
        IbragimovOhtaParkEntities db = new IbragimovOhtaParkEntities();
        Clients selectedClient;
        public AddOrderWin(Clients clients)
        {
            InitializeComponent();
            FilterCb.SelectedIndex = 0;
            selectedClient = clients;
            GetClients();          
        }

        public void GetClients()
        {
            if (FilterCb.SelectedIndex == 0)
            {
                ServiceLv.ItemsSource = db.Services.ToList();
            }
            if (FilterCb.SelectedIndex == 1)
            {
                ServiceLv.ItemsSource = db.Services.OrderBy(x => x.ServiceName).ToList();
            }
            if (FilterCb.SelectedIndex == 2)
            {
                ServiceLv.ItemsSource = db.Services.OrderByDescending(x => x.ServiceName).ToList();
            }
        }
      
        private void FilterCb_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            GetClients();
        }

        private void CreateOrderBtn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int hrs = 0; 
                int min = 0; 
                DateTime currentTime = DateTime.Now;

                if (ServiceLv.SelectedItems == null)
                {
                    MessageBox.Show("Выберите услугу", "Ошибка");
                    return;
                }

                if (TimeCb.SelectedIndex == -1)
                {
                    MessageBox.Show("Выберите время для услуги");
                    return;
                }

                if (TimeCb.SelectedIndex == 0) { hrs = 1; min = 0; }
                if (TimeCb.SelectedIndex == 1) { hrs = 1; min = 30; }
                if (TimeCb.SelectedIndex == 2) { hrs = 2; min = 0; }
                if (TimeCb.SelectedIndex == 3) { hrs = 2; min = 30; }


                // Создание нового заказа
                var order = new Orders
                {
                    OrderCode = selectedClient.ClientCode + "/" + currentTime.ToString("dd.MM.yyyy"), 
                    OrderDate = currentTime.Date, 
                    OrderTime = currentTime.TimeOfDay,
                    ClientCode_id = selectedClient.ClientCode,
                    Status_id = 3, 
                    HoursRent = hrs, 
                    MinutesRent = min 
                };

                // Добавление заказа в базу данных
                db.Orders.Add(order);
                db.SaveChanges();

                // Сохранение выбранных услуг для заказа
                foreach (var selectedService in ServiceLv.SelectedItems)
                {
                    var service = (Services)selectedService;

                    var orderDetail = new OrdersServices
                    {
                        OrderCode_id = order.OrderCode, 
                        Service_id = service.Id,
                    };

                    db.OrdersServices.Add(orderDetail);
                }

                db.SaveChanges();

                MessageBox.Show("Заказ создан");
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Вы не можете создать еще один заказ сегодня!");
            }
        }

        private void BackBtn_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
