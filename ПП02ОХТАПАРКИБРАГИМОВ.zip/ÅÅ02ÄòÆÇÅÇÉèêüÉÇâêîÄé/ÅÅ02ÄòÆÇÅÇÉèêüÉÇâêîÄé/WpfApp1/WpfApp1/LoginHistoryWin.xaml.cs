﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfApp1.Entities;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для LoginHistoryWin.xaml
    /// </summary>
    public partial class LoginHistoryWin : Window
    {
        IbragimovOhtaParkEntities db = new IbragimovOhtaParkEntities();
        public LoginHistoryWin()
        {
            InitializeComponent();
            GetEmployees();
        }
        private void FilterCb_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (this.FilterCb.SelectedIndex == 0)
            {
                EmployeesEntry.ItemsSource = db.Employees.ToList(); // Загружаем всех сотрудников
            }
            if (this.FilterCb.SelectedIndex == 1)
            {
                EmployeesEntry.ItemsSource = db.Employees.OrderBy(l => l.Login).ToList(); // Сортируем по логину по алфавиту
            }
            if (this.FilterCb.SelectedIndex == 2)
            {
                EmployeesEntry.ItemsSource = db.Employees.OrderByDescending(l => l.Login).ToList(); // Сортируем по логину против алфавита
            }
        }

        private void GetEmployees()
        {
            // Устанавливаем выбранный индекс на первый пункт и загружаем всех сотрудников в ListView
            FilterCb.SelectedIndex = 0;
            EmployeesEntry.ItemsSource = db.Employees.ToList();
        }

        private void exitBtn_Click(object sender, RoutedEventArgs e)
        {
            // Закрываем текущую форму и возвращаем пользователя на окно авторизации
            MainWindow mw = new MainWindow();
            mw.Show();
            this.Close();
        }
}
}
