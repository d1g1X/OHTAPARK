﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfApp1.Entities;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для NewOrderWin.xaml
    /// </summary>
    public partial class NewOrderWin : Window
    {
        IbragimovOhtaParkEntities db = new IbragimovOhtaParkEntities();
        public NewOrderWin()
        {
            InitializeComponent();
            GetClients();
        }

        public void GetClients()
        {
            var searchText = SearchTb.Text.ToLower();
            var client = db.Clients.Where(c => string.Concat(c.Surname.ToLower(), " ", c.Name.ToLower(), " ", c.Patronymic.ToLower()).Contains(searchText)).ToList();
            if (string.IsNullOrWhiteSpace(SearchTb.Text))
               ClientsList.ItemsSource = db.Clients.ToList();
            else
                ClientsList.ItemsSource = client;
        }

        private void AddClientBtn_Click(object sender, RoutedEventArgs e)
        {
            AddClientWin acw = new AddClientWin(this);
            acw.ShowDialog();
        }

        private void exitBtn_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            mw.Show();
            this.Close();
        }

        private void FilterCb_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (FilterCb.SelectedIndex == 0)
            {
                GetClients();
            }
            if (FilterCb.SelectedIndex == 1)
            {
                ClientsList.ItemsSource = db.Clients.OrderBy(x => x.Surname).ToList();
            }
            if (FilterCb.SelectedIndex == 2)
            {
                ClientsList.ItemsSource = db.Clients.OrderByDescending(x => x.Surname).ToList();
            }
        }

        private void SearchTb_TextChanged(object sender, TextChangedEventArgs e)
        {
            GetClients();
        }

        private void CreateOrderBtn_Click(object sender, RoutedEventArgs e)
        {
            if(ClientsList.SelectedItem == null)
            {
                MessageBox.Show("Выберите клиента для оформления заказа");
            }
            else
            {
                AddOrderWin addOrderWin = new AddOrderWin((Clients)ClientsList.SelectedItem);
                addOrderWin.ShowDialog();
            }
             
        }
    }
}
